"use client";

import * as React from "react";
import { CheckCircle2, Undo2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { roomsApi } from "@/features/rooms/api";
import { ApiError } from "@/lib/api-client";
import type { Room, RoomStageEvent, WorkflowStage } from "@/types";

/** Which package a review-gate stage belongs to — every key it's ever
 * called with starts with "ifa" or "ifc", same plain-prefix check
 * lib/room-workflow.ts::startLabel already uses for the detailer's own
 * Start button. */
function packageOf(stageKey: string): "IFA" | "IFC" {
  return stageKey.startsWith("ifa") ? "IFA" : "IFC";
}

/** The Team Leader/Manager's internal-review gate — "did this pass?" with
 * exactly two answers, each its own button, instead of a generic "pick a
 * target stage" dropdown. Feedback is the same free-text note the backend
 * has always accepted on any transition (RoomStageEvent.note) — just
 * required here specifically when sending it back, since "changes
 * needed" with no explanation isn't actionable for the detailer.
 *
 * §33: pulled out of the room detail page (app/(app)/rooms/[id]/page.tsx)
 * into its own shared file — used there via StageTransitionCard, AND on
 * the Team Leader/Manager's My Work "Needs your review" queue
 * (app/(app)/my-work/page.tsx), so it can't stay a page-local function
 * anymore. See docs/ARCHITECTURE.md §32/§33. */
export function ReviewGateCard({
  room,
  approveTarget,
  sendBackTarget,
  onTransitioned,
}: {
  room: Room;
  approveTarget: WorkflowStage | undefined;
  sendBackTarget: WorkflowStage | undefined;
  onTransitioned: (room: Room, event: RoomStageEvent) => void;
}) {
  const pkg = packageOf(room.workflow_stage.key);
  const [note, setNote] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState<"approve" | "send_back" | null>(null);

  async function run(action: "approve" | "send_back", target: WorkflowStage) {
    setError(null);
    setBusy(action);
    try {
      const event = await roomsApi.createStageTransition(room.id, {
        to_stage_key: target.key,
        outcome: null,
        note: note || null,
      });
      const updatedRoom = await roomsApi.get(room.id);
      onTransitioned(updatedRoom, event);
      setNote("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to move stage.");
    } finally {
      setBusy(null);
    }
  }

  function handleSendBack() {
    if (!sendBackTarget) return;
    if (!note.trim()) {
      setError("Add feedback for the detailer before sending this back.");
      return;
    }
    void run("send_back", sendBackTarget);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-semibold text-foreground">Internal Review</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor={`review-feedback-${room.id}`}>Feedback for the detailer</Label>
          <Textarea
            id={`review-feedback-${room.id}`}
            rows={3}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={`Any issues to flag? Required if you send this back — optional if you mark ${pkg} complete.`}
          />
        </div>

        {error && <p className="rounded-md bg-danger-bg px-3 py-2 text-sm text-danger">{error}</p>}

        <div className="flex flex-wrap items-center gap-2">
          {approveTarget && (
            <Button onClick={() => void run("approve", approveTarget)} disabled={busy !== null}>
              <CheckCircle2 className="h-4 w-4" />
              {busy === "approve" ? "Saving…" : `Mark ${pkg} Complete`}
            </Button>
          )}
          {sendBackTarget && (
            <Button
              onClick={handleSendBack}
              disabled={busy !== null}
              variant="outline"
              className="border-danger/40 text-danger hover:bg-danger-bg"
            >
              <Undo2 className="h-4 w-4" />
              {busy === "send_back" ? "Saving…" : "Send Back for Changes"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
