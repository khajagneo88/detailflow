"use client";

import * as React from "react";
import Link from "next/link";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { StageBadge } from "@/components/ui/stage-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { projectsApi } from "@/features/projects/api";
import { ApiError } from "@/lib/api-client";
import { BATCH_STATUS_LABELS, formatDate, stageVariant } from "@/lib/status";
import type { RoomStageTimelineItem } from "@/types";

/** BOM column: §33 moved BOM drafting off Batch entirely and onto the room
 * itself (WorkflowStage "bom_drafted", a Detailer's own step, done before a
 * room is even batched — see docs/ARCHITECTURE.md §33), so this reads the
 * room's own current stage now, not a batch status. "Done" once the room
 * has reached bom_drafted (or moved past it to complete — a batched room's
 * stage freezes at bom_drafted until its batch finishes, same "frozen
 * while batched" pattern lib/plan-colors.ts::roomCategory documents, so
 * bom_drafted itself already means "done drafting, waiting on a Nester").
 * There's no separate started/finished timestamp for this stage yet — see
 * RoomStageTimelineItem, which doesn't carry one — so, like the old
 * batch-status version of this cell, it's a standing/point-in-time column,
 * not a started/completed pair like IFA/IFC. */
function BomStageCell({ stageKey }: { stageKey: string }) {
  if (stageKey === "bom_drafted" || stageKey === "complete") {
    return <Badge variant="success">Done</Badge>;
  }
  return <span className="text-muted-foreground">—</span>;
}

/** Nesting column: a batch status badge only when nesting is where the
 * room's batch actually is right now; "Done" (muted) once the batch has
 * completed; "—" when there's no batch yet or it's still just `pending`
 * (grouped, not yet started). There's no per-phase timestamp to show a
 * date here — Batch has no status-history log, just its current status
 * plus created_at/updated_at (see docs/ARCHITECTURE.md §25) — so this is a
 * standing/point-in-time column too. */
function NestingPhaseCell({ status }: { status: RoomStageTimelineItem["batch_status"] }) {
  if (!status) return <span className="text-muted-foreground">—</span>;
  if (status === "nesting") {
    return <Badge variant="warning">{BATCH_STATUS_LABELS[status]}</Badge>;
  }
  if (status === "complete") return <Badge variant="success">Done</Badge>;
  return <span className="text-muted-foreground">—</span>;
}

function RevisionCell({ count }: { count: number }) {
  if (count === 0) return <span className="text-muted-foreground">—</span>;
  return <Badge variant="warning">{count}</Badge>;
}

/**
 * Per-room stage timeline for a whole project — when IFA/IFC started and
 * finished, how many times each came back for revision, and where the room
 * stands with its Batch (BOM/Nesting/batch number). One row per room,
 * distinct from the Apartments & Rooms tab's current-snapshot table: this
 * is the history/analytics view, that one is the working view. See
 * GET /projects/{id}/rooms/stage-timeline and docs/ARCHITECTURE.md §25.
 */
export function StageTimelineTable({ projectId }: { projectId: number }) {
  const [items, setItems] = React.useState<RoomStageTimelineItem[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    projectsApi
      .stageTimeline(projectId)
      .then(setItems)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load stage timeline."));
  }, [projectId]);

  if (error) return <p className="text-sm text-danger">{error}</p>;
  if (!items) return <p className="text-sm text-muted-foreground">Loading stage timeline…</p>;
  if (items.length === 0) {
    return <p className="px-1 py-3 text-sm text-muted-foreground">No rooms yet.</p>;
  }

  return (
    <Card>
      <CardContent className="overflow-x-auto p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Room</TableHead>
              <TableHead>Stage</TableHead>
              <TableHead>IFA Started</TableHead>
              <TableHead>IFA Completed</TableHead>
              <TableHead>IFA Revisions</TableHead>
              <TableHead>IFC Started</TableHead>
              <TableHead>IFC Completed</TableHead>
              <TableHead>IFC Revisions</TableHead>
              <TableHead>BOM</TableHead>
              <TableHead>Nesting</TableHead>
              <TableHead>Batch #</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.room_id}>
                <TableCell className="font-medium">
                  <Link
                    href={`/rooms/${item.room_id}`}
                    className="flex items-center gap-1.5 hover:text-primary hover:underline"
                  >
                    {item.room_name}
                  </Link>
                  {item.apartment_name && (
                    <span className="block text-xs font-normal text-muted-foreground">
                      {item.apartment_name}
                    </span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1.5">
                    <Badge variant={stageVariant(item.workflow_stage.key)}>
                      {item.workflow_stage.name}
                    </Badge>
                    <StageBadge
                      room={{
                        workflow_stage: item.workflow_stage,
                        batch:
                          item.batch_id !== null && item.batch_status !== null
                            ? { id: item.batch_id, batch_number: item.batch_number ?? 0, status: item.batch_status }
                            : null,
                      }}
                    />
                  </div>
                </TableCell>
                <TableCell className="whitespace-nowrap text-muted-foreground">
                  {formatDate(item.ifa_started_at)}
                </TableCell>
                <TableCell className="whitespace-nowrap text-muted-foreground">
                  {formatDate(item.ifa_completed_at)}
                </TableCell>
                <TableCell>
                  <RevisionCell count={item.ifa_revision_count} />
                </TableCell>
                <TableCell className="whitespace-nowrap text-muted-foreground">
                  {formatDate(item.ifc_started_at)}
                </TableCell>
                <TableCell className="whitespace-nowrap text-muted-foreground">
                  {formatDate(item.ifc_completed_at)}
                </TableCell>
                <TableCell>
                  <RevisionCell count={item.ifc_revision_count} />
                </TableCell>
                <TableCell>
                  <BomStageCell stageKey={item.workflow_stage.key} />
                </TableCell>
                <TableCell>
                  <NestingPhaseCell status={item.batch_status} />
                </TableCell>
                <TableCell>
                  {item.batch_id ? (
                    <Link
                      href={`/batches/${item.batch_id}`}
                      className="text-foreground hover:text-primary hover:underline"
                    >
                      Batch {item.batch_number}
                    </Link>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
