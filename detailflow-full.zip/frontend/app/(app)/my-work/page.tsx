"use client";

import * as React from "react";
import Link from "next/link";
import { AlertTriangle, CheckCircle2, PackageCheck, PlayCircle } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StageBadge } from "@/components/ui/stage-badge";
import { useAuth } from "@/features/auth/AuthContext";
import { batchesApi } from "@/features/batches/api";
import { roomsApi, workflowStagesApi } from "@/features/rooms/api";
import { ReviewGateCard } from "@/features/rooms/ReviewGateCard";
import { RoomActions } from "@/features/rooms/RoomActions";
import { ApiError } from "@/lib/api-client";
import { BUCKET_META, BUCKET_ORDER, Bucket, bucketFor } from "@/lib/room-workflow";
import {
  BATCH_STATUS_LABELS,
  PRIORITY_LABELS,
  PRIORITY_VARIANTS,
  ROOM_WORKFLOW_STATUS_LABELS,
  ROOM_WORKFLOW_STATUS_VARIANTS,
  batchStatusVariant,
  formatDate,
  formatDateTime,
  stageVariant,
} from "@/lib/status";
import type { Batch, Room, WorkflowStage } from "@/types";

/**
 * §33: My Work went from "a Detailer's assigned rooms, bucketed by
 * urgency" (the only thing this page ever did) to a role-aware landing
 * page — each role gets the queue the product ask actually described for
 * it, and nothing else:
 *  - Detailer (and a Team Leader acting as one on a room Planning assigned
 *    them — see plan_service.py) — the original bucketed queue, unchanged.
 *  - Nester — the shared pool of BOM-drafted, unbatched rooms to group (or
 *    nest solo), plus their own in-flight batches.
 *  - Team Leader / Manager / Admin — rooms sitting in internal review,
 *    with the same inline approve/send-back card the room detail page uses
 *    (see features/rooms/ReviewGateCard.tsx).
 *  - Ordering — BOM-drafted rooms whose materials haven't been ordered yet.
 * A Team Leader gets both the review queue AND (if they have any) the
 * detailer queue — the product ask was explicit that they do both jobs.
 */

// ---------------------------------------------------------------------------
// Detailer queue (and Team Leader acting as one)
// ---------------------------------------------------------------------------

function DetailerRoomRow({
  room,
  stages,
  onChanged,
}: {
  room: Room;
  stages: WorkflowStage[];
  onChanged: (room: Room) => void;
}) {
  return (
    <div className="flex flex-col gap-2 border-b border-border px-4 py-3 last:border-b-0 sm:flex-row sm:items-start sm:justify-between">
      <div className="flex flex-col gap-1">
        <Link
          href={`/rooms/${room.id}`}
          className="flex items-center gap-1.5 font-medium hover:text-primary hover:underline"
        >
          {room.workflow_status === "blocked" && (
            <AlertTriangle className="h-3.5 w-3.5 text-danger" />
          )}
          {room.name}
          <StageBadge room={room} />
        </Link>
        <p className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
          {room.project_name}
          {room.apartment_name && <> · {room.apartment_name}</>} ·
          <Badge variant={stageVariant(room.workflow_stage.key)}>{room.workflow_stage.name}</Badge>
        </p>
        <div className="flex flex-wrap items-center gap-2 pt-0.5">
          <Badge variant={PRIORITY_VARIANTS[room.priority]}>{PRIORITY_LABELS[room.priority]}</Badge>
          <Badge variant={ROOM_WORKFLOW_STATUS_VARIANTS[room.workflow_status]}>
            {ROOM_WORKFLOW_STATUS_LABELS[room.workflow_status]}
          </Badge>
          <span className="text-xs text-muted-foreground">Due {formatDate(room.due_date)}</span>
        </div>
      </div>

      <div className="sm:max-w-xs sm:shrink-0">
        <RoomActions
          room={room}
          stages={stages}
          onStatusChanged={onChanged}
          onTransitioned={(updated) => onChanged(updated)}
        />
      </div>
    </div>
  );
}

/** The original My Work content, unchanged in behaviour — rooms assigned to
 * `user` (GET /rooms/mine), bucketed by urgency. Used both for an actual
 * Detailer (always shown, even empty) and for a Team Leader who's been
 * handed a room via Planning (shown only once they actually have one — see
 * the `alwaysShow` prop). */
function DetailerSection({ alwaysShow }: { alwaysShow: boolean }) {
  const [rooms, setRooms] = React.useState<Room[] | null>(null);
  const [stages, setStages] = React.useState<WorkflowStage[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    Promise.all([roomsApi.listMine(), workflowStagesApi.list()])
      .then(([r, s]) => {
        setRooms(r);
        setStages(s);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load."));
  }, []);

  function handleChanged(updated: Room) {
    setRooms((prev) => prev?.map((r) => (r.id === updated.id ? updated : r)) ?? null);
  }

  if (error) return <p className="text-sm text-danger">{error}</p>;
  if (!rooms || !stages) {
    return <p className="text-sm text-muted-foreground">Loading your assigned rooms…</p>;
  }
  if (rooms.length === 0 && !alwaysShow) return null;

  const grouped = new Map<Bucket, Room[]>();
  for (const room of rooms) {
    const bucket = bucketFor(room);
    const list = grouped.get(bucket) ?? [];
    list.push(room);
    grouped.set(bucket, list);
  }

  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-lg font-semibold tracking-tight">Your assigned rooms</h2>

      {rooms.length === 0 && (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Nothing assigned to you yet.
          </CardContent>
        </Card>
      )}

      {BUCKET_ORDER.map((bucket) => {
        const bucketRooms = grouped.get(bucket);
        if (!bucketRooms || bucketRooms.length === 0) return null;
        return (
          <div key={bucket} className="flex flex-col gap-2">
            <div className="flex items-baseline gap-2">
              <h3 className="text-sm font-semibold text-foreground">{BUCKET_META[bucket].title}</h3>
              <span className="text-xs text-muted-foreground">
                {bucketRooms.length} · {BUCKET_META[bucket].hint}
              </span>
            </div>
            <Card>
              <CardContent className="p-0">
                {bucketRooms.map((room) => (
                  <DetailerRoomRow key={room.id} room={room} stages={stages} onChanged={handleChanged} />
                ))}
              </CardContent>
            </Card>
          </div>
        );
      })}
    </section>
  );
}

// ---------------------------------------------------------------------------
// Team Leader / Manager / Admin review queue
// ---------------------------------------------------------------------------

/** GET /rooms/needs-review's approve/send-back targets follow the exact
 * same mapping as StageTransitionCard on the room detail page
 * (app/(app)/rooms/[id]/page.tsx) — duplicated here rather than shared
 * since it's two lines and pulling in that whole dispatcher would be more
 * coupling than the two lines are worth. */
function reviewTargets(
  room: Room,
  stages: WorkflowStage[]
): { approveTarget: WorkflowStage | undefined; sendBackTarget: WorkflowStage | undefined } {
  const stageKey = room.workflow_stage.key;
  const approveKey = stageKey === "ifa_internal_review" ? "ifa_issued" : "ifc_issued";
  const sendBackKey = stageKey === "ifa_internal_review" ? "ifa_drafted" : "ifc_drafted";
  return {
    approveTarget: stages.find((s) => s.key === approveKey),
    sendBackTarget: stages.find((s) => s.key === sendBackKey),
  };
}

function ReviewQueueSection({ role }: { role: string | undefined }) {
  const [rooms, setRooms] = React.useState<Room[] | null>(null);
  const [stages, setStages] = React.useState<WorkflowStage[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(() => {
    Promise.all([roomsApi.listNeedsReview(), workflowStagesApi.list()])
      .then(([r, s]) => {
        setRooms(r);
        setStages(s);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load."));
  }, []);

  React.useEffect(load, [load]);

  function handleTransitioned(updated: Room) {
    // Once acted on, a room leaves the review queue outright (it's moved
    // to ifa_issued/ifc_issued or back to *_drafted, neither of which is a
    // review stage anymore) — drop it locally instead of a full refetch.
    setRooms((prev) => prev?.filter((r) => r.id !== updated.id) ?? null);
  }

  if (error) return <p className="text-sm text-danger">{error}</p>;
  if (!rooms || !stages) {
    return <p className="text-sm text-muted-foreground">Loading your review queue…</p>;
  }

  return (
    <section className="flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-semibold tracking-tight">Needs your review</h2>
        <p className="text-sm text-muted-foreground">
          {role === "team_leader"
            ? "Rooms in internal review across your projects."
            : "Rooms in internal review across every project."}
        </p>
      </div>

      {rooms.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Nothing waiting on your review.
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-4">
          {rooms.map((room) => {
            const { approveTarget, sendBackTarget } = reviewTargets(room, stages);
            return (
              <Card key={room.id}>
                <CardHeader className="flex-row items-start justify-between space-y-0">
                  <div className="flex flex-col gap-1">
                    <Link
                      href={`/rooms/${room.id}`}
                      className="font-medium hover:text-primary hover:underline"
                    >
                      {room.name}
                    </Link>
                    <p className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
                      {room.project_name}
                      {room.apartment_name && <> · {room.apartment_name}</>} ·
                      <Badge variant={stageVariant(room.workflow_stage.key)}>
                        {room.workflow_stage.name}
                      </Badge>
                    </p>
                  </div>
                  <span className="text-xs text-muted-foreground">Due {formatDate(room.due_date)}</span>
                </CardHeader>
                <CardContent className="pt-0">
                  <ReviewGateCard
                    room={room}
                    approveTarget={approveTarget}
                    sendBackTarget={sendBackTarget}
                    onTransitioned={handleTransitioned}
                  />
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </section>
  );
}

// ---------------------------------------------------------------------------
// Nester queue
// ---------------------------------------------------------------------------

interface RoomGroup {
  project_id: number;
  project_name: string | null;
  rooms: Room[];
}

function groupByProject(rooms: Room[]): RoomGroup[] {
  const byProject = new Map<number, RoomGroup>();
  for (const room of rooms) {
    const existing = byProject.get(room.project_id);
    if (existing) {
      existing.rooms.push(room);
    } else {
      byProject.set(room.project_id, {
        project_id: room.project_id,
        project_name: room.project_name,
        rooms: [room],
      });
    }
  }
  return Array.from(byProject.values());
}

function BatchRow({ batch, onChanged }: { batch: Batch; onChanged: (batch: Batch) => void }) {
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState<"start" | "complete" | null>(null);

  async function handleStart() {
    setError(null);
    setBusy("start");
    try {
      onChanged(await batchesApi.startNesting(batch.id));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to start nesting.");
    } finally {
      setBusy(null);
    }
  }

  async function handleComplete() {
    setError(null);
    setBusy("complete");
    try {
      onChanged(await batchesApi.createStatusTransition(batch.id, "complete"));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to complete nesting.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-col gap-2 border-b border-border px-4 py-3 last:border-b-0 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-col gap-1">
        <Link
          href={`/batches/${batch.id}`}
          className="font-medium hover:text-primary hover:underline"
        >
          Batch {batch.batch_number}
        </Link>
        <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <Badge variant={batchStatusVariant(batch.status)}>{BATCH_STATUS_LABELS[batch.status]}</Badge>
          {batch.room_count} room{batch.room_count === 1 ? "" : "s"}
          {batch.nesting_started_at && <> · Started {formatDateTime(batch.nesting_started_at)}</>}
        </p>
        {error && <p className="text-xs text-danger">{error}</p>}
      </div>
      <div className="flex items-center gap-2 sm:shrink-0">
        {batch.status === "pending" && (
          <Button size="sm" variant="outline" onClick={handleStart} disabled={busy !== null}>
            <PlayCircle className="h-3.5 w-3.5" />
            {busy === "start" ? "Starting…" : "Start Nesting"}
          </Button>
        )}
        {batch.status === "nesting" && (
          <Button size="sm" onClick={handleComplete} disabled={busy !== null}>
            <CheckCircle2 className="h-3.5 w-3.5" />
            {busy === "complete" ? "Saving…" : "Nesting Complete"}
          </Button>
        )}
      </div>
    </div>
  );
}

function NesterSection() {
  const [rooms, setRooms] = React.useState<Room[] | null>(null);
  const [batches, setBatches] = React.useState<Batch[] | null>(null);
  const [selected, setSelected] = React.useState<Set<number>>(new Set());
  const [error, setError] = React.useState<string | null>(null);
  const [busyProject, setBusyProject] = React.useState<number | null>(null);

  React.useEffect(() => {
    Promise.all([roomsApi.listBatchEligible(), batchesApi.listMine()])
      .then(([r, b]) => {
        setRooms(r);
        setBatches(b);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load."));
  }, []);

  function toggleRoom(id: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function handleBatch(group: RoomGroup, roomIds: number[]) {
    setError(null);
    setBusyProject(group.project_id);
    try {
      const created = await batchesApi.create(group.project_id, roomIds);
      setBatches((prev) => (prev ? [created, ...prev] : [created]));
      setRooms((prev) => prev?.filter((r) => !roomIds.includes(r.id)) ?? null);
      setSelected((prev) => {
        const next = new Set(prev);
        for (const id of roomIds) next.delete(id);
        return next;
      });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to create batch.");
    } finally {
      setBusyProject(null);
    }
  }

  function handleBatchChanged(updated: Batch) {
    // Nesting Complete moves a batch off this "your batches" list (My Work
    // only shows active batches — see batchesApi.listMine's backend
    // docstring), Start Nesting just updates it in place.
    setBatches((prev) =>
      prev
        ? updated.status === "complete"
          ? prev.filter((b) => b.id !== updated.id)
          : prev.map((b) => (b.id === updated.id ? updated : b))
        : prev
    );
  }

  if (error && !rooms && !batches) return <p className="text-sm text-danger">{error}</p>;
  if (!rooms || !batches) {
    return <p className="text-sm text-muted-foreground">Loading your nesting queue…</p>;
  }

  const groups = groupByProject(rooms);

  return (
    <section className="flex flex-col gap-6">
      <div className="flex flex-col gap-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Ready to batch or nest</h2>
          <p className="text-sm text-muted-foreground">
            BOM-drafted rooms, grouped by project — select one to nest it on its own, or several to
            batch them together.
          </p>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        {groups.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              No rooms are ready to batch right now.
            </CardContent>
          </Card>
        ) : (
          groups.map((group) => {
            const selectedInGroup = group.rooms.filter((r) => selected.has(r.id));
            return (
              <Card key={group.project_id}>
                <CardHeader className="flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-semibold text-foreground">
                    {group.project_name ?? `Project #${group.project_id}`}
                  </CardTitle>
                  <Button
                    size="sm"
                    disabled={selectedInGroup.length === 0 || busyProject !== null}
                    onClick={() =>
                      void handleBatch(
                        group,
                        selectedInGroup.map((r) => r.id)
                      )
                    }
                  >
                    {busyProject === group.project_id
                      ? "Saving…"
                      : selectedInGroup.length === 1
                        ? "Nest this room"
                        : selectedInGroup.length > 1
                          ? `Batch ${selectedInGroup.length} rooms`
                          : "Select rooms to batch"}
                  </Button>
                </CardHeader>
                <CardContent className="p-0">
                  <ul className="divide-y divide-border">
                    {group.rooms.map((room) => (
                      <li key={room.id}>
                        <label className="flex cursor-pointer items-center gap-3 px-4 py-2.5 text-sm hover:bg-surface-muted">
                          <input
                            type="checkbox"
                            checked={selected.has(room.id)}
                            onChange={() => toggleRoom(room.id)}
                            className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
                          />
                          <span className="flex-1">
                            <Link
                              href={`/rooms/${room.id}`}
                              className="font-medium hover:text-primary hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {room.name}
                            </Link>
                            {room.apartment_name && (
                              <span className="text-muted-foreground"> · {room.apartment_name}</span>
                            )}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            Due {formatDate(room.due_date)}
                          </span>
                        </label>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      <div className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Your batches</h2>
        {batches.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              No batches in progress.
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-0">
              {batches.map((batch) => (
                <BatchRow key={batch.id} batch={batch} onChanged={handleBatchChanged} />
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Ordering queue
// ---------------------------------------------------------------------------

function OrderingSection() {
  const [rooms, setRooms] = React.useState<Room[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busyRoomId, setBusyRoomId] = React.useState<number | null>(null);

  React.useEffect(() => {
    roomsApi
      .listReadyToOrder()
      .then(setRooms)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Failed to load."));
  }, []);

  async function handleMarkOrdered(room: Room) {
    setError(null);
    setBusyRoomId(room.id);
    try {
      await roomsApi.markMaterialsOrdered(room.id);
      setRooms((prev) => prev?.filter((r) => r.id !== room.id) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to mark materials ordered.");
    } finally {
      setBusyRoomId(null);
    }
  }

  if (error && !rooms) return <p className="text-sm text-danger">{error}</p>;
  if (!rooms) {
    return <p className="text-sm text-muted-foreground">Loading rooms ready to order…</p>;
  }

  return (
    <section className="flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-semibold tracking-tight">Ready to order</h2>
        <p className="text-sm text-muted-foreground">
          BOM-drafted rooms whose materials haven&apos;t been ordered yet.
        </p>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}

      {rooms.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Nothing waiting on an order right now.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            {rooms.map((room) => (
              <div
                key={room.id}
                className="flex flex-col gap-2 border-b border-border px-4 py-3 last:border-b-0 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex flex-col gap-1">
                  <Link
                    href={`/rooms/${room.id}`}
                    className="font-medium hover:text-primary hover:underline"
                  >
                    {room.name}
                  </Link>
                  <p className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
                    {room.project_name}
                    {room.apartment_name && <> · {room.apartment_name}</>} · Due{" "}
                    {formatDate(room.due_date)}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => void handleMarkOrdered(room)}
                  disabled={busyRoomId !== null}
                >
                  <PackageCheck className="h-3.5 w-3.5" />
                  {busyRoomId === room.id ? "Saving…" : "Mark Materials Ordered"}
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </section>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function MyWorkPage() {
  const { user } = useAuth();
  const role = user?.role;

  const showReview = role === "team_leader" || role === "manager" || role === "admin";
  const showNester = role === "nester";
  const showOrdering = role === "ordering";
  const showDetailer = role === "detailer" || role === "team_leader";
  const showNothing = !showReview && !showNester && !showOrdering && !showDetailer;

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">My Work</h1>
        <p className="text-sm text-muted-foreground">
          Everything that&apos;s on you right now, ordered by what needs you first.
        </p>
      </div>

      {showReview && <ReviewQueueSection role={role} />}
      {showNester && <NesterSection />}
      {showOrdering && <OrderingSection />}
      {/* A Team Leader only sees this section once they actually have an
          assigned room (see alwaysShow) — otherwise it'd be an empty card
          under their review queue every single time, for a job most Team
          Leaders aren't doing most days. A plain Detailer always sees it —
          it's their whole page. */}
      {showDetailer && <DetailerSection alwaysShow={role === "detailer"} />}

      {showNothing && (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            There&apos;s no work queue set up for your role yet.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
