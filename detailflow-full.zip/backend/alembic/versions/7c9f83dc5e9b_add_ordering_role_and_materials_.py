"""add ordering role and rooms.materials_ordered_at

Revision ID: 7c9f83dc5e9b
Revises: 97b8f6ebe1ba
Create Date: 2026-09-16 12:10:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7c9f83dc5e9b'
down_revision: Union[str, None] = '97b8f6ebe1ba'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Adding a value to an existing native Postgres enum can't run inside
    # the same transaction as other DDL — same autocommit_block pattern
    # b7c2f4a9d1e3 used for notification_type. The literal is the enum
    # member's *name* (uppercase) — see that migration's note.
    with op.get_context().autocommit_block():
        op.execute("ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'ORDERING'")

    op.add_column("rooms", sa.Column("materials_ordered_at", sa.DateTime(timezone=True)))


def downgrade() -> None:
    op.drop_column("rooms", "materials_ordered_at")
    # Postgres has no "DROP VALUE" for enums — same documented limitation as
    # every other enum-value-addition migration in this codebase.
