"""simplify batch_status: drop bom_pending/bom_review, add pending

Revision ID: 97b8f6ebe1ba
Revises: f6bb7a01a08e
Create Date: 2026-09-16 12:05:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '97b8f6ebe1ba'
down_revision: Union[str, None] = 'f6bb7a01a08e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# §33: BOM drafting moved off Batch entirely (see app/models/batch.py and
# BatchStatus's docstring) — a Batch is now just pending -> nesting ->
# complete. Postgres enum values can be added or renamed in place, but not
# *removed* without recreating the type, so this rebuilds batch_status from
# scratch: a new type with the 3 remaining values, existing rows remapped
# (bom_pending and bom_review both fold into pending — either way, nothing
# left for a Team Leader to review at the batch level anymore), the column
# repointed at it, and the old type dropped.
#
# The literal values here are the Python enum members' *names* (uppercase)
# — what SQLAlchemy's native Enum actually stores by default, not
# .value — see 79e1794040f1_add_batches.py's own
# sa.Enum('BOM_PENDING', 'BOM_REVIEW', 'NESTING', 'COMPLETE', ...) and
# b7c2f4a9d1e3's note on notification_type for the same gotcha.
_NEW_VALUES = ("PENDING", "NESTING", "COMPLETE")


def upgrade() -> None:
    conn = op.get_bind()

    op.execute("ALTER TYPE batch_status RENAME TO batch_status_old")
    new_enum = sa.Enum(*_NEW_VALUES, name="batch_status")
    new_enum.create(conn)

    op.execute(
        """
        ALTER TABLE batches
        ALTER COLUMN status TYPE batch_status
        USING (
            CASE status::text
                WHEN 'BOM_PENDING' THEN 'PENDING'
                WHEN 'BOM_REVIEW' THEN 'PENDING'
                ELSE status::text
            END
        )::batch_status
        """
    )
    op.execute("ALTER TABLE batches ALTER COLUMN status SET DEFAULT 'PENDING'::batch_status")
    op.execute("DROP TYPE batch_status_old")

    # bom_started_at (Batch.py) no longer exists — BOM is a per-room
    # Detailer step now, not a per-batch one. Any batch currently mid-BOM
    # (which just became `pending`) loses this purely-informational
    # timestamp; nothing else read it.
    op.drop_column("batches", "bom_started_at")


def downgrade() -> None:
    # Not meaningfully reversible — two old values folded into one new
    # value, and the dropped column's data is gone. Same no-op precedent as
    # every other data-shape migration in this codebase.
    pass
