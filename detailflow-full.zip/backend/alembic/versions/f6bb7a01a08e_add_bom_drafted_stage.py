"""add bom_drafted workflow stage

Revision ID: f6bb7a01a08e
Revises: c3d8e5a1f9b2
Create Date: 2026-09-16 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f6bb7a01a08e'
down_revision: Union[str, None] = 'c3d8e5a1f9b2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# §33: BOM drafting moved off Batch and onto Room as its own stage — a
# Detailer's single-click step, done per-room, between IFC Issued and
# Complete. Must match DEFAULT_WORKFLOW_STAGES in
# app/models/workflow_stage.py.
_NEW_SEQUENCE = {
    "ifa_drafted": 1,
    "ifa_internal_review": 2,
    "ifa_issued": 3,
    "ifa_revision": 4,
    "ifc_drafted": 5,
    "ifc_internal_review": 6,
    "ifc_issued": 7,
    "ifc_revision": 8,
    "bom_drafted": 9,
    "complete": 10,
}

_workflow_stages = sa.table(
    "workflow_stages",
    sa.column("id", sa.Integer),
    sa.column("key", sa.String),
    sa.column("name", sa.String),
    sa.column("sequence", sa.Integer),
)
_rooms = sa.table(
    "rooms",
    sa.column("id", sa.Integer),
    sa.column("workflow_stage_id", sa.Integer),
    sa.column("progress", sa.Integer),
)


def upgrade() -> None:
    conn = op.get_bind()

    id_by_key = {
        row.key: row.id
        for row in conn.execute(sa.select(_workflow_stages.c.id, _workflow_stages.c.key))
    }

    # Nothing to insert/renumber on a database whose workflow_stages table
    # hasn't been seeded yet — same "run before seed.py ever runs" no-op
    # precedent a1f3c9d2e6b7 established.
    if "ifc_issued" not in id_by_key:
        return

    # Renumber every existing stage out of the way first (two-pass, same
    # "offset out of range, then the real value" trick a1f3c9d2e6b7 used) so
    # the `sequence` UNIQUE constraint is never violated.
    for key, seq in _NEW_SEQUENCE.items():
        if key not in id_by_key:
            continue
        conn.execute(
            _workflow_stages.update()
            .where(_workflow_stages.c.id == id_by_key[key])
            .values(sequence=seq + 1000)
        )
    for key, seq in _NEW_SEQUENCE.items():
        if key not in id_by_key:
            continue
        conn.execute(
            _workflow_stages.update()
            .where(_workflow_stages.c.id == id_by_key[key])
            .values(sequence=seq)
        )

    # Insert the new stage, if this database doesn't already have it.
    if "bom_drafted" not in id_by_key:
        conn.execute(
            _workflow_stages.insert().values(
                key="bom_drafted", name="BOM Drafted", sequence=_NEW_SEQUENCE["bom_drafted"]
            )
        )

    # Recompute every room's progress against the new 10-stage total — the
    # old percentages were computed as sequence / 9, stale now for every
    # room, not just ones sitting at/after the new stage. Mirrors
    # app/services/room_service.py::compute_progress.
    id_by_key = {
        row.key: row.id
        for row in conn.execute(sa.select(_workflow_stages.c.id, _workflow_stages.c.key))
    }
    total_stages = len(_NEW_SEQUENCE)
    new_seq_by_stage_id = {
        id_by_key[key]: seq for key, seq in _NEW_SEQUENCE.items() if key in id_by_key
    }
    for stage_id, seq in new_seq_by_stage_id.items():
        conn.execute(
            _rooms.update()
            .where(_rooms.c.workflow_stage_id == stage_id)
            .values(progress=round((seq / total_stages) * 100))
        )


def downgrade() -> None:
    # Not meaningfully reversible — same no-op precedent as
    # a1f3c9d2e6b7/7c527eb18338 for a data-shape migration with no way to
    # faithfully restore what changed.
    pass
